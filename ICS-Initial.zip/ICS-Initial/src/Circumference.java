public class Circumference {

    public static void main (String[] args) {

        double rayon = 5.5;
        double aire = Math.pow(5.5, 2);
        double pi = 3.141592653589793238462643383279502884197169399375;
        double circonference = 2*rayon*pi;

        System.out.println(aire*pi);
        System.out.println(circonference);

    }
}
