public class Lines {

    public static void main (String[] args) {

        System.out.println("Bienvenue a la programmation Java.");
        System.out.println("Bienvenue aux " + "sciences informatiques.");
        System.out.println("La programmation est amusante!");
        System.out.println("Il y a beaucoup d<emplois dans le domaine de l'informatique.");
        System.out.println("On doit etre patient et autonome pour pouvoir programmer.");


    }

}
