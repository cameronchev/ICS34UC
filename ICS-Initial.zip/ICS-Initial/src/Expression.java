public class Expression {

    public static void main (String[] args) {

        double top = (9.5*4.5 - 2.5*3);
        double bottom = 45.5-3.5;

        System.out.println(top/bottom);

    }

}
