public class Rectangle {

    public static void main (String[] args) {

        double largeur = 4.5;
        double longueur = 7.9;
        double aire = largeur*longueur;

        System.out.println(aire);

    }
}
