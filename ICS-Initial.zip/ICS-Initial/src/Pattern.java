public class Pattern {

    public static void main (String[] args) {

        System.out.println("J    " + "A    " + "V   " + "V   " + "A");
        System.out.println("J    " + "A " + "A    " + "V  " + "V   " + "A " + "A");
        System.out.println("J     " + "J  " + "AAAAA   " + "VV    " + "AAAAA");
        System.out.println("J  " + "J  " + "A     " + "A   " + "V    " + "A    " + "A");

    }
}
