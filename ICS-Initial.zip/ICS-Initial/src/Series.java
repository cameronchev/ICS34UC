public class Series {

    public static void main (String[] args) {

        int i = 1;
        int f = 0;
        while (i <= 9) {
            f = f + i;
            i++;
        }

        System.out.println(f);

    }

}
